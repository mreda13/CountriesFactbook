//
//  CurrencyConversionResponse.swift
//  CountriesFactbook
//
//  Created by Mohamed Metwaly on 2019-06-17.
//  Copyright © 2019 Udacity. All rights reserved.
//

import Foundation

struct CurrencyConversionResponse:Decodable {
    
    
    
}
