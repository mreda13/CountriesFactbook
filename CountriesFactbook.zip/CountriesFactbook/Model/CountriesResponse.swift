//
//  CountriesResponse.swift
//  CountriesFactbook
//
//  Created by Mohamed Metwaly on 2019-06-16.
//  Copyright © 2019 Udacity. All rights reserved.
//

import Foundation

struct CountriesResponse:Codable {
    let countries:[CountryResponse]
}
